# fire > 2024-05-06 8:33pm
https://universe.roboflow.com/intelegente-artificial/fire-nwmci

Provided by a Roboflow user
License: CC BY 4.0

